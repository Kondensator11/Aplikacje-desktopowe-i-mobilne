﻿using System;
public class zadanie6c
{

    public static void Main(string[] args)
    {
        Console.WriteLine("wprowadz poczatek przedzialu: ");
        int poczatek = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("wprowadz koniec przedzialu: ");
        int koniec = Convert.ToInt32(Console.ReadLine());
        do
        {
            if (poczatek <= koniec)
            {
                for (int i = poczatek; i <= koniec; i++)
                {
                    Console.Write(i + " ");
                }
                break;
            }
            else
                Console.WriteLine("bledny przedzial");
            break;
        }
        while (true);
    }
}