﻿using System;
public class zadaine4
{
    public static void Main(string[] args)
    {
        int liczba = 0;
        do
        {
            Console.WriteLine("wybierz co chcesz zrobic: (0 = koniec / 1 dodawanie / 2 = odejmowanie / 3 = mnozenie / 4 = dzielenie");
            liczba = Convert.ToInt32(Console.ReadLine());
        }
        while (liczba != 0);
        Console.WriteLine("koniec");
    }
}