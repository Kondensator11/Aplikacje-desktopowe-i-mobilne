﻿using System;
public class zadanie1
{
    public static void Main(string[] args)
    {
        int liczba;
        int suma = 0;

        do
        {
            Console.WriteLine("podaj liczbe(po jej wpisanu liczba ujemna program sumuje podane liczby): ");
            liczba= int.Parse(Console.ReadLine());
            if (liczba >= 0)
            {
                suma += liczba;
            }
        } while(liczba >= 0);
        Console.WriteLine("Oto suma tych liczb: " + suma);
    }
}