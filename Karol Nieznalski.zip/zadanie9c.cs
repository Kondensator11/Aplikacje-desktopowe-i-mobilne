﻿using System;

public class Zad9c
{
    public static void Main(string[] args)
    {
        for (; true;)
        {
            Console.Write("Podaj poczatek przedzialu: ");
            int poczatek = int.Parse(Console.ReadLine());
            Console.Write("Podaj koniec przedzialu: ");
            int koniec = int.Parse(Console.ReadLine());
            if (poczatek < koniec)
            {
                for (; poczatek <= koniec; poczatek++)
                {
                    if(poczatek % 3 == 0)
                    {
                        Console.Write(poczatek + " ");
                    }
                }
                break;
            }
        }
    }
}
