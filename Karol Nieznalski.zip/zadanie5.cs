﻿﻿using System;
using System.Reflection.Metadata.Ecma335;
public class zadanie5
{
    public static void Main(string[] args)
    {
        string haslo;
        Console.WriteLine("wpisz haslo ");
        string haslo1 = Convert.ToString(Console.ReadLine());
        do
        {
            Console.WriteLine("wpisz poprawne haslo ");
            haslo = Convert.ToString(Console.ReadLine());
            if (haslo == haslo1)
            {
                break;
            }
            else
                continue;
        }
        while (haslo != haslo1);
        Console.WriteLine("poprawne haslo");
            
            
    } 

}
    