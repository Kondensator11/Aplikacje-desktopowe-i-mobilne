﻿using System;

public class Zad8b
{
    public static void Main(string[] args)
    {
        int liczba = 1;
        int suma = 0;
        while (liczba >= 0)
        {
            Console.Write("Podaj liczbe(po wpisaniu liczby ujemej program sumuje podane liczby): ");
            liczba = int.Parse(Console.ReadLine());
            if (liczba >= 0)
            {
                suma += liczba;
            }

        }
        Console.WriteLine("Oto suma tych liczb: " + suma);
    }
}
