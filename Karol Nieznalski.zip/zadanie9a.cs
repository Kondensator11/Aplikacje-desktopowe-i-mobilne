﻿using System;

public class Zad9a
{
    public static void Main(string[] args)
    {
        do
        {
            Console.Write("Podaj poczatek przedzialu: ");
            int poczatek = int.Parse(Console.ReadLine());
            Console.Write("Podaj koniec przedzialu: ");
            int koniec = int.Parse(Console.ReadLine());
            if (poczatek < koniec)
            {
                do
                {
                    if(poczatek % 3 == 0)
                    {
                        Console.Write(poczatek + " ");
                    }
                    poczatek++;
                } while (poczatek <= koniec);
                break;
            }
        } while (true);
    }
}
