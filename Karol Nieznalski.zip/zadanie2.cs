﻿using System;
public class zadanie2
{
    public static void Main(string[] args)
    {
        int liczba = 0;
        int x = 0;
        Random generatorliczb = new Random();
        x = generatorliczb.Next(0, 10);
        do
        {
            Console.WriteLine("zgadnij liczbe z przediału od 0 do 10: ");
            liczba = Convert.ToInt32(Console.ReadLine());
            if (liczba != x)
            {
                Console.WriteLine("zła liczba");
            }

        }
        while (liczba != x);
        Console.WriteLine("Brawa udalo sie");
    }
}
