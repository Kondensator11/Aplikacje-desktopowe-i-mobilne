﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        while (true)
        {
            Console.Write("Podaj poczatek przedzialu: ");
            int poczatek = int.Parse(Console.ReadLine());
            Console.Write("Podaj koniec przedzialu: ");
            int koniec = int.Parse(Console.ReadLine());
            if (poczatek < koniec)
            {
                while (poczatek <= koniec)
                {
                    if(poczatek % 3 == 0)
                    {
                        Console.Write(poczatek + " ");
                    }
                    poczatek++;
                }
                break;
            }
        }
    }
}
