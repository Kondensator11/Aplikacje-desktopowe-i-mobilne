﻿using System;
public class zadanie6a
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Wprowadz koniec przedzialu: ");
        int poczatek = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("wprowadz koniec przedzialu: ");
        int koniec = Convert.ToInt32(Console.ReadLine());
        if (poczatek <= koniec)
        {
            for (int i = poczatek; i <= koniec; i++)
            {
                Console.Write(i + " ");
            }
        }
        else
            Console.WriteLine("bledny przedzial");
    }
}