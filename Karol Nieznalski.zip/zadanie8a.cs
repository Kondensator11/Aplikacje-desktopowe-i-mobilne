﻿using System;

public class Zad8a
{
    public static void Main(string[] args)
    {

        int liczba;
        int suma = 0;
        do
        {
            Console.Write("Podaj liczbe(po wpisaniu liczby ujemej program sumuje podane liczby): ");
            liczba = int.Parse(Console.ReadLine());
            if (liczba >= 0)
            {
                suma += liczba;
            }

        }while(liczba >= 0);
        Console.WriteLine("Oto suma tych liczb: " + suma);
    }
}
