﻿using System;
public class zadanie3
{
    public static void Main(string[] args)
    {
        int silnia = 1;
        do
        {
            Console.WriteLine("Wprowadz liczbe z jakiej chcesz obliczyc silnie: ");
            int liczba = Convert.ToInt32(Console.ReadLine());
            if (liczba > 0)
            {
                for (int i = 1; i <= liczba; i++)
                {
                    silnia += i;
                }
            }
        }
        while (false); 
        Console.WriteLine("silnia wprowadzonej liczby wynosi:" + silnia);
    }
}