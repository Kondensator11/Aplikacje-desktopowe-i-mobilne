﻿using System;
public class zadanie6
{
    public static void Main(string[] args)
    {
        Console.WriteLine("zadanie 6");

        do
        {
            Console.WriteLine(" 1 -> suma liczb / 2 -> różnica / 3 -> Zakoncz program");
            int liczba = Convert.ToInt32(Console.ReadLine());
            int wynik = 0;
            if(liczba == 1)
            {
                Console.WriteLine("podaj pierwsza liczbe: ");
                int x = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("podaj druga liczbe: ");
                int y = Convert.ToInt32(Console.ReadLine());
                wynik = x + y;
                Console.WriteLine(wynik);
                continue;

            }
            else if (liczba == 2)
            {
                Console.WriteLine("podaj pierwsza liczbe: ");
                int x = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("podaj druga liczbe: ");
                int y = Convert.ToInt32(Console.ReadLine());
                wynik = x - y;
                Console.WriteLine(wynik);
                continue;
            }
            else if (liczba == 3)
            {
                break;
            }
        }
        while (true);
    }   
}