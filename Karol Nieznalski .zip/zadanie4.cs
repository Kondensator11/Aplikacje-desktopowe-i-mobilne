﻿using System;
public class zadanie4
{
    public static void Main(string[] args)
    {
        Console.WriteLine("zadanie 4");

        Console.WriteLine("podaj liczcbe");
        string liczba = Convert.ToString(Console.ReadLine());

        while(true)
        {
            int dlugosc = liczba.Length;
            Console.WriteLine(dlugosc);
            break;
        }
    }
}