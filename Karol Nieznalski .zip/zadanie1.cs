﻿using System;
public class zadanie1
{
    public static void Main(string[] args)
    {
        Console.WriteLine("zadanie 1");

        int a = 1;
        int b = 1;
        int c = 1;
        int x;
        int y;
        for(y = 1; y <=10; y++)
        {
            Console.WriteLine("Mnożenie liczby: " + c);
            for(x = 1; x <=10; x++)
            {
                b = (x * a);
                Console.WriteLine(b + " ");
            }
            c++;
            a++;
        }
    }
}