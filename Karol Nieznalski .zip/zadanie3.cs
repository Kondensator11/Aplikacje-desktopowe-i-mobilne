﻿using System;
public class zadanie1
{
    public static void Main(string[] args)
    {
        Console.WriteLine("zadanie 3");
        Console.WriteLine("zgadnij cyfre: ");
        Random rnd = new Random();
        int x1 = rnd.Next(1, 101);

        while (true)
        {
            int x2 =Convert.ToInt32(Console.ReadLine());
            if (x1 == x2)
            {
                Console.WriteLine("brawo zgadles cyfre");
                break;
            }
            else if (x2 < x1)
            {
                Console.WriteLine("za mała");
            }
            else if(x2 > x1)
            {
                Console.WriteLine("za duża");  
            }
        }
    }
}
