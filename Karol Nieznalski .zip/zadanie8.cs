﻿using System;

public class zadanie8
{
    public static void Main(string[] args)
    {
        Console.WriteLine("zadanie8");

        Console.WriteLine("podaj wysokosc prostokata");
        int wysokosc = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("podaj bok prostokata");
        int bok = Convert.ToInt32(Console.ReadLine());

        for(int i = 1; i <= bok ; i++)
        {
            Console.Write("*");
        }
        Console.WriteLine();
        for(int o = 0; o < (wysokosc - 2) ; o++)
        {
            Console.Write("*");
            for (int x = 1; x <= (bok - 2); x++)
            {
                Console.Write(" ");
            }
            Console.WriteLine("*");

        }
        for(int i = 1; i <= bok; i++)
        {
            Console.Write("*");
        }

    }
}
