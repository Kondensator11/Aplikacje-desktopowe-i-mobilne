﻿using System;

public class zadanie7
{
    public static void Main(string[] args)
    {
        Console.WriteLine("zadanie 7");

        do
        {
            Console.WriteLine("podaj haslo");
            string haslo = Convert.ToString(Console.ReadLine());
            string haslo1 = "secure123";
            if (haslo == haslo1)
            {
                Console.WriteLine("poprawne haslo");
                break;

            }
            else
            {
                Console.WriteLine("bledne haslo sprobuj ponownie");
            }
        }
        while (true);
    }
}