﻿using System;
public class zadanie1
{
    public static void Main(string[] args)
    {
        Console.WriteLine("zadanie 1");
        Console.WriteLine("podaj liczbe: ");
        int x = Convert.ToInt32(Console.ReadLine());
        int suma = 0;
        for(int a = 0; a <= x; a++)
        {
            if(x % 2 == 0)
            {
                Console.WriteLine(a);
                suma += a;
            }
            a++;
        }
        Console.WriteLine("suma wynosi: " + suma);
    }
}